-- phpMyAdmin SQL Dump
-- version 4.7.1
-- https://www.phpmyadmin.net/
--
-- Host: sql10.freemysqlhosting.net
-- Tempo de geração: 18/07/2020 às 21:22
-- Versão do servidor: 5.5.62-0ubuntu0.14.04.1
-- Versão do PHP: 7.0.33-0ubuntu0.16.04.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `sql10355402`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `Alunos`
--

CREATE TABLE `Alunos` (
  `idAluno` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `endereco` varchar(100) NOT NULL,
  `telefone` varchar(11) NOT NULL,
  `dataDeNascimento` date NOT NULL,
  `idCurso` int(11) NOT NULL,
  `idTurma` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `Alunos`
--

INSERT INTO `Alunos` (`idAluno`, `nome`, `endereco`, `telefone`, `dataDeNascimento`, `idCurso`, `idTurma`) VALUES
(1, 'Gustavo Andrade Gosmatti de Lima', 'Rua Lemes', '4197223850', '1998-06-23', 1, 1),
(2, 'Andre Nunes', 'Rua Santos', '54644564', '1998-05-15', 1, 1),
(3, 'dasdas', 'dasds', '1111111111', '1198-06-23', 2, 4),
(4, 'Marli', 'Rua Cid', '41997223850', '2012-12-15', 1, 5);

-- --------------------------------------------------------

--
-- Estrutura para tabela `Curso`
--

CREATE TABLE `Curso` (
  `idCurso` int(11) NOT NULL,
  `nomeCurso` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `Curso`
--

INSERT INTO `Curso` (`idCurso`, `nomeCurso`) VALUES
(1, 'Matematica'),
(2, 'Administraçao'),
(3, 'Educaçao Fisisca'),
(5, 'Informatica'),
(6, 'Portugues'),
(7, 'adasdsd'),
(8, 'Abacaxi'),
(9, 'Cortador de arvore'),
(10, 'Historia');

-- --------------------------------------------------------

--
-- Estrutura para tabela `Disciplina`
--

CREATE TABLE `Disciplina` (
  `idDisciplina` int(11) NOT NULL,
  `nomeDisciplina` varchar(100) NOT NULL,
  `cargaHoraria` int(11) NOT NULL,
  `idCurso` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `Disciplina`
--

INSERT INTO `Disciplina` (`idDisciplina`, `nomeDisciplina`, `cargaHoraria`, `idCurso`) VALUES
(1, 'Calculo 1', 15, 1),
(2, 'Algebra', 20, 1),
(3, 'Calculo 2', 15, 1),
(4, 'Verbos', 60, 6),
(5, 'Banco de dados 2', 20, 5),
(6, 'Lenhador de cana', 36, 9),
(7, 'Guerras', 12, 10);

-- --------------------------------------------------------

--
-- Estrutura para tabela `Nota`
--

CREATE TABLE `Nota` (
  `idNota` int(11) NOT NULL,
  `notaDisciplina` double NOT NULL,
  `idAluno` int(11) NOT NULL,
  `idDisciplina` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `Nota`
--

INSERT INTO `Nota` (`idNota`, `notaDisciplina`, `idAluno`, `idDisciplina`) VALUES
(1, 5, 1, 1),
(2, 4.5, 1, 2),
(3, 7.5, 2, 1),
(4, 10, 2, 3),
(5, 6.3, 2, 2),
(6, 5.5, 1, 3),
(10, 10, 4, 1),
(11, 10, 4, 2);

-- --------------------------------------------------------

--
-- Estrutura para tabela `Professor`
--

CREATE TABLE `Professor` (
  `idProfessor` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `endereco` varchar(100) NOT NULL,
  `telefone` varchar(11) NOT NULL,
  `dataDeNascimento` date NOT NULL,
  `titulacao` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `Professor`
--

INSERT INTO `Professor` (`idProfessor`, `nome`, `endereco`, `telefone`, `dataDeNascimento`, `titulacao`) VALUES
(1, 'Ricardo Silva', 'Rua Gomes Silva', '14564561', '1980-07-15', 'Mestre'),
(2, 'Antonio', 'Rua Rocha', '41165456', '1952-02-10', 'Doutor'),
(3, 'Antunes', 'Rua Lemes Silva Santos', '41997223850', '1985-08-15', 'Doutor'),
(4, 'sadas', 'dasd', '41997223850', '1648-05-15', 'dasdasd'),
(5, 'dasdsasd', 'dasdss', '1111111111', '2154-03-14', 'asdads'),
(6, 'Lucas Roberto Silva', 'Rua Rocha Silva', '11111111111', '0001-01-01', 'Mestre');

-- --------------------------------------------------------

--
-- Estrutura para tabela `Turma`
--

CREATE TABLE `Turma` (
  `idTurma` int(11) NOT NULL,
  `nomeTurma` varchar(100) NOT NULL,
  `idCurso` int(11) NOT NULL,
  `idProfessor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `Turma`
--

INSERT INTO `Turma` (`idTurma`, `nomeTurma`, `idCurso`, `idProfessor`) VALUES
(1, 'Turma A', 1, 1),
(2, 'Turma B', 3, 2),
(3, 'Turma C', 6, 2),
(4, 'Turma D', 2, 3),
(5, 'Turma G', 1, 3),
(6, 'Turma T', 8, 6),
(7, 'Turma L', 10, 6);

--
-- Índices de tabelas apagadas
--

--
-- Índices de tabela `Alunos`
--
ALTER TABLE `Alunos`
  ADD PRIMARY KEY (`idAluno`);

--
-- Índices de tabela `Curso`
--
ALTER TABLE `Curso`
  ADD PRIMARY KEY (`idCurso`);

--
-- Índices de tabela `Disciplina`
--
ALTER TABLE `Disciplina`
  ADD PRIMARY KEY (`idDisciplina`);

--
-- Índices de tabela `Nota`
--
ALTER TABLE `Nota`
  ADD PRIMARY KEY (`idNota`);

--
-- Índices de tabela `Professor`
--
ALTER TABLE `Professor`
  ADD PRIMARY KEY (`idProfessor`);

--
-- Índices de tabela `Turma`
--
ALTER TABLE `Turma`
  ADD PRIMARY KEY (`idTurma`);

--
-- AUTO_INCREMENT de tabelas apagadas
--

--
-- AUTO_INCREMENT de tabela `Alunos`
--
ALTER TABLE `Alunos`
  MODIFY `idAluno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de tabela `Curso`
--
ALTER TABLE `Curso`
  MODIFY `idCurso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT de tabela `Disciplina`
--
ALTER TABLE `Disciplina`
  MODIFY `idDisciplina` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT de tabela `Nota`
--
ALTER TABLE `Nota`
  MODIFY `idNota` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT de tabela `Professor`
--
ALTER TABLE `Professor`
  MODIFY `idProfessor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT de tabela `Turma`
--
ALTER TABLE `Turma`
  MODIFY `idTurma` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
