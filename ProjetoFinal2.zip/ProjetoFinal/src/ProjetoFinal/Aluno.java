package ProjetoFinal;

import java.util.Date;

public class Aluno extends Pessoa {

	private int numMatricula;
	private int codCurso;
	private int codTurma;

	public int getCodTurma() {
		return codTurma;
	}

	public void setCodTurma(int codTurma) {
		this.codTurma = codTurma;
	}

	public int getNumMatricula() {
		return numMatricula;
	}

	public void setNumMatricula(int numMatricula) {
		this.numMatricula = numMatricula;
	}

	public int getCurso() {
		return codCurso;
	}

	public void setCurso(int codCurso) {
		this.codCurso = codCurso;
	}

}
