package ProjetoFinal;

import java.util.List;

public class Curso {
	
	private String nomeCurso;
	
	
	
	
	public String getNomeCurso() {
		return nomeCurso;
	}
	public void setNomeCurso(String nomeCurso) {
		this.nomeCurso = nomeCurso;
	}

}
