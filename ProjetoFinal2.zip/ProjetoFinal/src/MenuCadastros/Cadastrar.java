package MenuCadastros;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.InputMismatchException;
import java.util.Scanner;

import ProjetoFinal.Aluno;
import ProjetoFinal.Curso;
import ProjetoFinal.Disciplina;
import ProjetoFinal.Professor;
import ProjetoFinal.Turma;
import QuerysBanco.CursoDAO;
import QuerysBanco.ProfessorDAO;
import QuerysBanco.TurmaDAO;

public class Cadastrar {

	public Aluno CadastrarAluno() {
		int opcCurso;
		int codCurso = 0;
		int opcTurma;
		int codTurma = 0;
		CursoDAO c = new CursoDAO();
		TurmaDAO t = new TurmaDAO();
		Scanner s = new Scanner(System.in);
		boolean valida = false;
		Aluno a = new Aluno();
		do {
			System.out.println("Digite o nome do aluno: ");
			a.setNome(s.nextLine());

			if (!a.getNome().matches("^[\\w\\s&&[^\\d]]+$")) {
				System.out.println("DIGITE SOMENTE LETRAS!!\n");
			}
		} while (!a.getNome().matches("^[\\w\\s&&[^\\d]]+$"));

		do {
			System.out.println("Digite o endere�o do aluno:");
			a.setEndereco(s.nextLine());

			if (!a.getEndereco().matches("^[\\w\\s&&[^\\d]]+$")) {
				System.out.println("DIGITE SOMENTE LETRAS!!\n");
			}
		} while (!a.getEndereco().matches("^[\\w\\s&&[^\\d]]+$"));

		do {
			System.out.println("Digite o telefone do aluno:");
			a.setTelefone(s.nextLine());
			if (!a.getTelefone().matches("[0-9]+")) {
				System.out.println("DIGITE SOMENTE N�MEROS!!\n");
			}
			else if(a.getTelefone().length()<10 || a.getTelefone().length()>11) {
				System.out.println("DIGITE UM N�MERO DE TELEFONE V�LIDO COM NO M�NIMO 10 DIGITOS E NO M�XIMO 11!!\n");
				System.out.println("EXEMPLO: 4190002222\n");
			}
		} while (!a.getTelefone().matches("[0-9]+") || a.getTelefone().length()>11 || a.getTelefone().length()<10);

		do {

			try {
				System.out.println("Digite a data de nascimento do aluno: ");
				a.setDataDeNascimento(s.nextLine());

				SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
				dateFormat.setLenient(false);
				valida = false;

				dateFormat.parse(a.getDataDeNascimento());
				valida = true;

			} catch (ParseException e) {
				System.out.println("DIGITE UMA DATA V�LIDA COM O FORMATO: dia / m�s / ano");
				valida = false;

			}
		} while (valida == false);

		

		do {
			do {
				System.out.println("Escolha o curso que deseja matricular esse aluno: \n");
				try {
					c.listarCursos();
					System.out.println("c - Cadastrar novo curso\n");
					String opcCurso1 = s.nextLine();
					if (opcCurso1.contentEquals("c")) {
						CursoDAO cursoDao = new CursoDAO();
						cursoDao.CadastrarCurso((cadastrarCurso()));
						codCurso = 0;

					} else {

						codCurso = c.ListarCursoPorId(Integer.parseInt(opcCurso1));
					}
					valida = true;
				} catch (InputMismatchException e) {
					System.out.println("DIGITE SOMENTE N�MEROS OU 'c' PARA CADASTRAR UM NOVO CURSO !!");
				} catch (NumberFormatException e) {
					System.out.println("DIGITE SOMENTE N�MEROS OU 'c' PARA CADASTRAR UM NOVO CURSO !!");
				}
			} while (valida == false);

		} while (codCurso == 0);

		
		do {
			do {
				System.out.println("Escolha a turma que deseja matricular esse aluno: \n");
				try {
					t.listarTurmaPorCurso(codCurso);
					System.out.println("c - Cadastrar nova turma\n");
					String opcTurma1 = s.nextLine();
					if (opcTurma1.equals("c")) {

						TurmaDAO turmaDao = new TurmaDAO();
						turmaDao.cadastrarTurma(cadastrarTurma());
						codTurma = 0;
					} else {
						codTurma = t.listarTurmaPorId(codCurso,Integer.parseInt(opcTurma1));
					}
					valida = true;
				} catch (InputMismatchException e) {
					System.out.println("DIGITE SOMENTE N�MEROS OU 'c' PARA CADASTRAR UMA NOVA TURMA !!");
				} catch (NumberFormatException e) {
					System.out.println("DIGITE SOMENTE N�MEROS OU 'c' PARA CADASTRAR UMA NOVA TURMA !!");
				}
			} while (valida == false);
		} while (codTurma == 0);
		a.setCurso(codCurso);
		a.setCodTurma(codTurma);

		return a;

	}

	public Curso cadastrarCurso() {
		Scanner s = new Scanner(System.in);
		Curso c = new Curso();

		do {
			System.out.println("Digite o nome do curso: ");
			c.setNomeCurso(s.nextLine());

			if (!c.getNomeCurso().matches("^[\\w\\s&&[^\\d]]+$")) {
				System.out.println("DIGITE SOMENTE LETRAS!!\n");
			}
		} while (!c.getNomeCurso().matches("^[\\w\\s&&[^\\d]]+$"));
		return c;

	}

	public Disciplina cadastrarDisciplina() {
		CursoDAO c = new CursoDAO();
		Scanner s = new Scanner(System.in);
		Disciplina d = new Disciplina();
		String opcCurso;
		int codCurso = 0;
		boolean valida = false;

		do {

			do {
				System.out.println("Escolha o curso que deseja vincular a essa disciplina: \n");
				try {
					c.listarCursos();
					System.out.println("c - Cadastrar novo curso\n");
					opcCurso = s.nextLine();
					if (opcCurso.equals("c")) {
						CursoDAO cursoDao = new CursoDAO();
						cursoDao.CadastrarCurso(cadastrarCurso());
						codCurso = 0;
					} else {
						codCurso = c.ListarCursoPorId(Integer.parseInt(opcCurso));

					}
					valida = true;
				} catch (InputMismatchException e) {
					System.out.println("DIGITE SOMENTE N�MEROS OU 'c' PARA CADASTRAR UM NOVO CURSO !!");
				} catch (NumberFormatException e) {
					System.out.println("DIGITE SOMENTE N�MEROS OU 'c' PARA CADASTRAR UM NOVO CURSO !!");
				}

			} while (valida == false);
		} while (codCurso == 0);

		System.out.println("Digite o nome da disciplina: ");
		d.setNomeDisciplina(s.nextLine());
		do {
			try {
				System.out.println("Digite a carga horaria da disciplina: ");
				d.setCargaHoraria(s.nextInt());
				d.setCodCurso(codCurso);
				valida = true;
			} catch (InputMismatchException e) {
				System.out.println("DIGITE SOMENTE N�MEROS!!\n");
				valida = false;
				s.nextLine();
			}
		} while (valida == false);

		return d;

	}

	public Professor cadastrarProfessor() {

		Scanner s = new Scanner(System.in);
		boolean valida = false;
		Professor p = new Professor();
		do {
			System.out.println("Digite o nome do professor: ");
			p.setNome(s.nextLine());

			if (!p.getNome().matches("^[\\w\\s&&[^\\d]]+$")) {
				System.out.println("DIGITE SOMENTE LETRAS!!\n");
			}
		} while (!p.getNome().matches("^[\\w\\s&&[^\\d]]+$"));

		do {
			System.out.println("Digite a titula��o do professor: ");
			p.setTitulacao(s.nextLine());

			if (!p.getTitulacao().matches("^[\\w\\s&&[^\\d]]+$")) {
				System.out.println("DIGITE SOMENTE LETRAS!!\n");
			}
		} while (!p.getTitulacao().matches("^[\\w\\s&&[^\\d]]+$"));

		do {
			System.out.println("Digite o endere�o do professor:");
			p.setEndereco(s.nextLine());

			if (!p.getEndereco().matches("^[\\w\\s&&[^\\d]]+$")) {
				System.out.println("DIGITE SOMENTE LETRAS!!\n");
			}
		} while (!p.getEndereco().matches("^[\\w\\s&&[^\\d]]+$"));

		do {
			System.out.println("Digite o telefone do professor:");
			p.setTelefone(s.nextLine());
			if (!p.getTelefone().matches("[0-9]+")) {
				System.out.println("DIGITE SOMENTE N�MEROS\n");
			}
			else if(p.getTelefone().length()<10 || p.getTelefone().length()>11) {
				System.out.println("DIGITE UM N�MERO DE TELEFONE V�LIDO COM NO M�NIMO 10 DIGITOS E NO M�XIMO 11!!\n");
				System.out.println("EXEMPLO: 4190002222\n");
			}
		} while (!p.getTelefone().matches("[0-9]+") || p.getTelefone().length()>11 || p.getTelefone().length()<10);

		do {

			try {
				System.out.println("Digite a data de nascimento do professor: ");
				p.setDataDeNascimento(s.nextLine());

				SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
				dateFormat.setLenient(false);
				valida = false;

				dateFormat.parse(p.getDataDeNascimento());
				valida = true;

			} catch (ParseException e) {
				System.out.println("DIGITE UMA DATA V�LIDA COM O FORMATO: dia / m�s / ano");
				valida = false;
				

			}
		} while (valida == false);
		return p;

	}

	public Turma cadastrarTurma() {

		CursoDAO c = new CursoDAO();
		Scanner s = new Scanner(System.in);
		ProfessorDAO p = new ProfessorDAO();
		Turma t = new Turma();

		int opcCurso;
		String opcProfessor;
		int codCurso = 0;
		int codProfessor = 0;
		boolean valida = false;

		do {
			do {
				System.out.println("Escolha o curso que deseja vincular a essa turma: \n");
				try {
					c.listarCursos();
					System.out.println("c - Cadastrar novo curso\n");
					String opcCurso1 = s.nextLine();
					if (opcCurso1.contentEquals("c")) {
						CursoDAO cursoDao = new CursoDAO();
						cursoDao.CadastrarCurso((cadastrarCurso()));
						codCurso = 0;

					} else {

						codCurso = c.ListarCursoPorId(Integer.parseInt(opcCurso1));
					}
					valida = true;
				} catch (InputMismatchException e) {
					System.out.println("DIGITE SOMENTE N�MEROS OU 'c' PARA CADASTRAR UM NOVO CURSO !!");
				} catch (NumberFormatException e) {
					System.out.println("DIGITE SOMENTE N�MEROS OU 'c' PARA CADASTRAR UM NOVO CURSO !!");
				}
			} while (valida == false);

		} while (codCurso == 0);

		System.out.println("Escolha o professor que deseja vincular a essa turma: \n");
		do {
			do {
				try {
					p.listarProfessores();
					System.out.println("c - Cadastrar novo professor\n");
					opcProfessor = s.nextLine();
					if (opcProfessor.equals("c")) {
						ProfessorDAO profDao = new ProfessorDAO();
						profDao.cadastrarProfessor(cadastrarProfessor());
						codProfessor = 0;
					} else {
						codProfessor = p.listarProfessorPorId(Integer.parseInt(opcProfessor));
					}
					valida = true;
				} catch (InputMismatchException e) {
					System.out.println("DIGITE SOMENTE N�MEROS OU 'c' PARA CADASTRAR UM NOVO PROFESSOR !!");
				} catch (NumberFormatException e) {
					System.out.println("DIGITE SOMENTE N�MEROS OU 'c' PARA CADASTRAR UM NOVO PROFESSOR !!");
				}
			} while (valida == false);
		} while (codProfessor == 0);

		System.out.println("Digite o nome da turma: ");
		t.setNomeTurma(s.nextLine());
		t.setCodCurso(codCurso);
		t.setCodProfessor(codProfessor);

		return t;

	}
}
