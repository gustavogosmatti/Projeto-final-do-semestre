package QuerysBanco;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import ProjetoFinal.Disciplina;

public class DisciplinaDAO {

	public void cadastrarDisciplina(Disciplina d) {

		String sql = "INSERT INTO Disciplina(nomeDisciplina,cargaHoraria,idCurso)" + " VALUES(?,?,?)";

		Connection con = null;
		java.sql.PreparedStatement pstm = null;

		try {

			con = Conexao.Conectar();
			pstm = con.prepareStatement(sql);

			pstm.setString(1, d.getNomeDisciplina());
			pstm.setInt(2, d.getCargaHoraria());
			pstm.setInt(3, d.getCodCurso());

			pstm.execute();
		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			// Fecha as conex�es

			try {
				if (pstm != null) {

					pstm.close();
				}

				if (con != null) {
					con.close();
				}

			} catch (Exception e) {

				e.printStackTrace();
			}
		}

	}

	public boolean listarDisciplinasDoCurso(int codCurso) {

		String sql = "SELECT idDisciplina, nomeDisciplina FROM Disciplina WHERE Disciplina.idCurso = " + codCurso;
		Connection con = null;
		Statement pstm = null;
		boolean valida = false;
		try {

			con = Conexao.Conectar();
			pstm = con.prepareStatement(sql);

			ResultSet rs = pstm.executeQuery(sql);
			if (rs.next()) {
				do {
					int codDisciplina = rs.getInt("idDisciplina");
					String nomeDisciplina = rs.getString("nomeDisciplina");

					System.out.println(codDisciplina + " - " + nomeDisciplina);
				} while (rs.next());
				valida = true;
			}

			else {
				System.out.println("N�O H� DISCIPLINAS CADASTRADAS NESTE CURSO!!\n");
				valida = false;
			}

		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			// Fecha as conex�es

			try {
				if (pstm != null) {

					pstm.close();
				}

				if (con != null) {
					con.close();
				}

			} catch (Exception e) {

				e.printStackTrace();
			}

		}
		return valida;

	}

	public int listarDisciplinaPorId(int idDisciplina) {
		String sql = "SELECT idDisciplina FROM Disciplina WHERE idDisciplina = " + idDisciplina;
		Connection con = null;
		Statement pstm = null;
		int codDisciplina = 0;

		try {

			con = Conexao.Conectar();
			pstm = con.prepareStatement(sql);

			ResultSet rs = pstm.executeQuery(sql);
			while (rs.next()) {
				codDisciplina = rs.getInt("idDisciplina");
			}
		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			// Fecha as conex�es

			try {
				if (pstm != null) {

					pstm.close();
				}

				if (con != null) {
					con.close();
				}

			} catch (Exception e) {

				e.printStackTrace();
			}

		}

		return codDisciplina;
	}

	public void listarDisciplinasPorCurso() {

		CursoDAO cursoDao = new CursoDAO();
		Scanner s = new Scanner(System.in);
		int opcCurso;
		int codCurso;

		System.out.println("Escolha o curso que deseja listar as disciplinas: \n");
		do {
			cursoDao.listarCursos();
			opcCurso = s.nextInt();
			codCurso = cursoDao.ListarCursoPorId(opcCurso);
		} while (codCurso == 0);

		String sql = "SELECT Curso.nomeCurso, Disciplina.nomeDisciplina, Disciplina.cargaHoraria FROM Disciplina "
				+ "INNER JOIN Curso ON Disciplina.idCurso = Curso.idCurso " + " WHERE Disciplina.idCurso = " + codCurso;

		Connection con = null;
		Statement pstm = null;

		try {

			con = Conexao.Conectar();
			pstm = con.prepareStatement(sql);

			ResultSet rs = pstm.executeQuery(sql);

			boolean aux = false;
			if (rs.next()) {
				do {
					String nomeCurso = rs.getString("nomeCurso");

					String nomeDisciplina = rs.getString("nomeDisciplina");
					int cargaHoraria = rs.getInt("cargaHoraria");
					if (aux == false) {
						System.out.println("Curso: " + nomeCurso.toUpperCase());
						aux = true;
					}
					System.out.println("Disciplina: " + nomeDisciplina);
					System.out.println("Carga horaria: " + cargaHoraria + "\n");
				} while (rs.next());
			} else {
				System.out.println("N�O H� DISCIPLINAS CADASTRADAS NESTE CURSO!!!\n");
			}

		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			// Fecha as conex�es

			try {
				if (pstm != null) {

					pstm.close();
				}

				if (con != null) {
					con.close();
				}

			} catch (Exception e) {

				e.printStackTrace();
			}

		}

	}

}
