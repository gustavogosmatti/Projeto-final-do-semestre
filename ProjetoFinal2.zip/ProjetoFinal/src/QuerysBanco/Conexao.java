package QuerysBanco;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.mysql.jdbc.Driver;




public class Conexao {
	
	
	//Nome de usu�rio do mysql
	private static final String USERNAME = "sql10357484";
	// Senha do mysql
	private static final String PASSWORD = "iFLiPCM9nc";
	
	//Dados de caminho, porta e nome da base de dados que ir� ser feita a conex�o
	private static final String DATABASE_URL = "jdbc:mysql://sql10.freemysqlhosting.net/sql10357484";

	public static Connection Conectar() throws Exception {
		
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(DATABASE_URL,USERNAME, PASSWORD);
			
		
			
		return con;
	}
}
