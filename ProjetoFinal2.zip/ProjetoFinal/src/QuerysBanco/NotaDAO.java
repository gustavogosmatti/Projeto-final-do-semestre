package QuerysBanco;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import ProjetoFinal.Nota;

public class NotaDAO {

	public void CadastrarNotaDisciplina(Nota n) {

		String sql = "INSERT INTO Nota(notaDisciplina,idAluno,idDisciplina)" + " VALUES(?,?,?)";

		Connection con = null;
		java.sql.PreparedStatement pstm = null;

		try {

			con = Conexao.Conectar();
			pstm = con.prepareStatement(sql);

			pstm.setDouble(1, n.getNota());
			pstm.setInt(2, n.getCodAluno());
			pstm.setInt(3, n.getCodDisciplina());

			pstm.execute();
		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			// Fecha as conex�es

			try {
				if (pstm != null) {

					pstm.close();
				}

				if (con != null) {
					con.close();
				}

			} catch (Exception e) {

				e.printStackTrace();
			}
		}
	}

	public int verificarSeNotaExiste(int codAluno, int codDisciplina) {
		String sql = "SELECT idNota FROM Nota WHERE idAluno = " + codAluno + " AND idDisciplina = " + codDisciplina;
		Connection con = null;
		Statement pstm = null;
		int idNota = -1;

		try {
			con = Conexao.Conectar();

			pstm = con.prepareStatement(sql);
			ResultSet rs = pstm.executeQuery(sql);

			if (rs.next()) {
				do {
					idNota = rs.getInt("idNota");
				} while (rs.next());

			} else {
				idNota = -1;
			}
		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			// Fecha as conex�es

			try {
				if (pstm != null) {

					pstm.close();
				}

				if (con != null) {
					con.close();
				}

			} catch (Exception e) {

				e.printStackTrace();
			}

		}

		return idNota;

	}

	public void alterarNota(int idNota, double notaDisciplina) {
		String sql = "UPDATE Nota SET notaDisciplina = " + notaDisciplina + " WHERE idNota = " + idNota;

		Connection con = null;
		Statement pstm = null;

		try {
			con = Conexao.Conectar();

			pstm = con.prepareStatement(sql);
			pstm.executeUpdate(sql);

		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			// Fecha as conex�es

			try {
				if (pstm != null) {

					pstm.close();
				}

				if (con != null) {
					con.close();
				}

			} catch (Exception e) {

				e.printStackTrace();
			}

		}

	}

	public void listarRelatorioAcademicoAluno(int codCurso, int idAluno) {

		String sql = "SELECT Alunos.nome, Nota.notaDisciplina, Disciplina.nomeDisciplina FROM Nota"
				+ " INNER JOIN Alunos ON Nota.idAluno = Alunos.idAluno"
				+ " INNER JOIN Disciplina ON Nota.idDisciplina = Disciplina.idDisciplina" + " WHERE Alunos.idAluno = "
				+ idAluno + " ORDER BY Disciplina.idDisciplina";

		Connection con = null;
		Statement pstm = null;

		try {
			boolean aux = false;
			con = Conexao.Conectar();

			pstm = con.prepareStatement(sql);
			ResultSet rs = pstm.executeQuery(sql);
			ResultSet rs2;
			if (rs.next()) {
				do {
					String nomeAluno = rs.getString("nome");
					double notaDisciplina = rs.getDouble("notaDisciplina");
					String nomeDisciplina = rs.getString("nomeDisciplina");

					if (aux == false) {

						System.out.println("Aluno: " + nomeAluno);
						aux = true;

					}
					System.out.println("Disciplina: " + nomeDisciplina);
					System.out.println("Nota: " + notaDisciplina);
				} while (rs.next());

			}

			else {
				System.out.println("NENHUMA DISCIPLINA FOI AVALIADA PARA ESTE ALUNO!!\n");
			}

		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			// Fecha as conex�es

			try {
				if (pstm != null) {

					pstm.close();
				}

				if (con != null) {
					con.close();
				}

			} catch (Exception e) {

				e.printStackTrace();
			}

		}

	}

}
