package QuerysBanco;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import ProjetoFinal.Professor;

public class ProfessorDAO {

	public void cadastrarProfessor(Professor p) {

		String sql = "INSERT INTO Professor(nome,endereco,telefone,dataDeNascimento,titulacao)" + " VALUES(?,?,?,?,?)";

		Connection con = null;
		java.sql.PreparedStatement pstm = null;

		try {

			con = Conexao.Conectar();
			pstm = con.prepareStatement(sql);

			pstm.setString(1, p.getNome());
			pstm.setString(2, p.getEndereco());
			pstm.setString(3, p.getTelefone());
			DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			Date date = new java.sql.Date(((java.util.Date) formatter.parse(p.getDataDeNascimento())).getTime());
			pstm.setDate(4, date);
			pstm.setString(5, p.getTitulacao());

			pstm.execute();
		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			// Fecha as conex�es

			try {
				if (pstm != null) {

					pstm.close();
				}

				if (con != null) {
					con.close();
				}

			} catch (Exception e) {

				e.printStackTrace();
			}
		}
	}

	public void listarProfessores() {
		String sql = "SELECT idProfessor, nome FROM Professor";
				

		Connection con = null;
		Statement pstm = null;

		try {

			con = Conexao.Conectar();
			pstm = con.prepareStatement(sql);

			ResultSet rs = pstm.executeQuery(sql);
			System.out.println("-------LISTA DE PROFESSORES--------");
			while (rs.next()) {
				int idProfessor = rs.getInt("idProfessor");
				String nome = rs.getString("nome");

				System.out.println(idProfessor +" - "+nome);
				
			}

		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			// Fecha as conex�es

			try {
				if (pstm != null) {

					pstm.close();
				}

				if (con != null) {
					con.close();
				}

			} catch (Exception e) {

				e.printStackTrace();
			}

		}

	}
	public int listarProfessorPorId(int idProfessor) {
		String sql = "SELECT idProfessor FROM Professor WHERE idProfessor = " + idProfessor;
		Connection con = null;
		Statement pstm = null;
		int codProfessor = 0;

		try {

			con = Conexao.Conectar();
			pstm = con.prepareStatement(sql);

			ResultSet rs = pstm.executeQuery(sql);
			while (rs.next()) {
				codProfessor = rs.getInt("idProfessor");
			}
		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			// Fecha as conex�es

			try {
				if (pstm != null) {

					pstm.close();
				}

				if (con != null) {
					con.close();
				}

			} catch (Exception e) {

				e.printStackTrace();
			}

		}
		return codProfessor;
	}
	
}
