package QuerysBanco;

import com.mysql.jdbc.PreparedStatement;

import ProjetoFinal.Aluno;

import java.sql.Date;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class AlunoDAO {

	public void CadastrarAluno(Aluno aluno) {
		String sql = "INSERT INTO Alunos(nome,endereco,telefone,dataDeNascimento,idCurso,idTurma)"
				+ " VALUES(?,?,?,?,?,?)";

		Connection con = null;
		java.sql.PreparedStatement pstm = null;

		try {

			con = Conexao.Conectar();
			pstm = con.prepareStatement(sql);

			pstm.setString(1, aluno.getNome());
			pstm.setString(2, aluno.getEndereco());
			pstm.setString(3, aluno.getTelefone());
			DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			Date date = new java.sql.Date(((java.util.Date) formatter.parse(aluno.getDataDeNascimento())).getTime());
			pstm.setDate(4, date);
			pstm.setInt(5, aluno.getCurso());
			pstm.setInt(6, aluno.getCodTurma());

			pstm.execute();
		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			// Fecha as conex�es

			try {
				if (pstm != null) {

					pstm.close();
				}

				if (con != null) {
					con.close();
				}

			} catch (Exception e) {

				e.printStackTrace();
			}
		}
	}

	public boolean listarAlunos(int idTurma, int idCurso) {
		String sql = "SELECT Alunos.idAluno, Alunos.nome FROM Alunos"
				+ " WHERE Alunos.idTurma = " + idTurma 
				+ " AND Alunos.idCurso = " + idCurso;

		Connection con = null;
		Statement pstm = null;
		boolean valida = false;

		try {
			boolean aux = false;
			con = Conexao.Conectar();
			pstm = con.prepareStatement(sql);

			ResultSet rs = pstm.executeQuery(sql);
			if (rs.next()) {
				do {

					String idAluno = rs.getString("idAluno");
					String nomeAluno = rs.getNString("nome");

					System.out.println(idAluno + " - " + nomeAluno);
				} while (rs.next());
				valida = true;
			} else {
				System.out.println("N�O H� ALUNOS CADASTRADOS !!\n");
				valida = false;
			}

		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			// Fecha as conex�es

			try {
				if (pstm != null) {

					pstm.close();
				}

				if (con != null) {
					con.close();
				}

			} catch (Exception e) {

				e.printStackTrace();
			}

		}
		return valida;

	}

	public int listarAlunosPorId(int codTurma, int codCurso, int idAluno) {

		String sql = "SELECT idAluno FROM Alunos WHERE idAluno = " + idAluno + " AND idTurma = " + codTurma
				+ " AND idCurso = " + codCurso;
		Connection con = null;
		Statement pstm = null;
		int codAluno = 0;

		try {

			con = Conexao.Conectar();
			pstm = con.prepareStatement(sql);

			ResultSet rs = pstm.executeQuery(sql);
			while (rs.next()) {
				codAluno = rs.getInt("idAluno");
			}
		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			// Fecha as conex�es

			try {
				if (pstm != null) {

					pstm.close();
				}

				if (con != null) {
					con.close();
				}

			} catch (Exception e) {

				e.printStackTrace();
			}

		}

		return codAluno;
	}

	public boolean listarAlunosPorCurso(int idTurma, int idCurso) {

		String sql = "SELECT Turma.nomeTurma, Curso.nomeCurso, Alunos.nome FROM Alunos"
				+ " INNER JOIN Curso ON Alunos.idCurso = Curso.idCurso "
				+ "INNER JOIN Turma ON Alunos.idTurma = Turma.idTurma" + " WHERE Alunos.idTurma = " + idTurma
				+ " AND Alunos.idCurso = " + idCurso;

		Connection con = null;
		Statement pstm = null;
		boolean valida = false;

		try {
			boolean aux = false;
			con = Conexao.Conectar();
			pstm = con.prepareStatement(sql);

			ResultSet rs = pstm.executeQuery(sql);
			if (rs.next()) {
				do {
					String nomeTurma = rs.getString("nomeTurma");
					String nomeCurso = rs.getString("nomeCurso");
					String nomeAluno = rs.getNString("nome");

					if (aux == false) {
						System.out.println("Turma: " + nomeTurma);
						System.out.println("Curso: " + nomeCurso);
						aux = true;

					}
					System.out.println("Aluno: " + nomeAluno);

				} while (rs.next());
				valida = true;
			} else {
				System.out.println("N�O H� ALUNOS CADASTRADOS NESTE CURSO!!\n");
				valida = false;
			}
		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			// Fecha as conex�es

			try {
				if (pstm != null) {

					pstm.close();
				}

				if (con != null) {
					con.close();
				}

			} catch (Exception e) {

				e.printStackTrace();
			}

		}
		return valida;

	}

}
