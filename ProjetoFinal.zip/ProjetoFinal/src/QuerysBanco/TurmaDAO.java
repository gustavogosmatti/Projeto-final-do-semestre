package QuerysBanco;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import ProjetoFinal.Turma;

public class TurmaDAO {

	public void cadastrarTurma(Turma t) {
		String sql = "INSERT INTO Turma(nomeTurma,idCurso,idProfessor)" + " VALUES(?,?,?)";

		Connection con = null;
		java.sql.PreparedStatement pstm = null;

		try {

			con = Conexao.Conectar();
			pstm = con.prepareStatement(sql);

			pstm.setString(1, t.getNomeTurma());
			pstm.setInt(2, t.getCodCurso());
			pstm.setInt(3, t.getCodProfessor());

			pstm.execute();
		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			// Fecha as conex�es

			try {
				if (pstm != null) {

					pstm.close();
				}

				if (con != null) {
					con.close();
				}

			} catch (Exception e) {

				e.printStackTrace();
			}
		}
	}

	public void listarTurmas() {
		String sql = "SELECT Turma.nomeTurma, Professor.nome FROM Turma"
				+ " INNER JOIN Professor ON Turma.idProfessor = Professor.idProfessor ";
		Connection con = null;
		Statement pstm = null;

		try {

			con = Conexao.Conectar();
			pstm = con.prepareStatement(sql);

			ResultSet rs = pstm.executeQuery(sql);

			while (rs.next()) {
				String nomeTurma = rs.getString("nomeTurma");
				String nomeProfessor = rs.getString("nome");

				System.out.println("Turma: " + nomeTurma + " - Professor: " + nomeProfessor);

			}

		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			// Fecha as conex�es

			try {
				if (pstm != null) {

					pstm.close();
				}

				if (con != null) {
					con.close();
				}

			} catch (Exception e) {

				e.printStackTrace();
			}

		}
	}

	public boolean listarTurmaPorCurso(int idCurso) {

		String sql = "SELECT Turma.idTurma, Turma.nomeTurma FROM Turma"
				+ " WHERE Turma.idCurso = " + idCurso;
		Connection con = null;
		Statement pstm = null;
		boolean valida = false;

		try {

			con = Conexao.Conectar();
			pstm = con.prepareStatement(sql);

			ResultSet rs = pstm.executeQuery(sql);

			if (rs.next()) {
				do {
					int idTurma = rs.getInt("idTurma");
					String nomeTurma = rs.getString("nomeTurma");

					System.out.println(idTurma + " - " + nomeTurma);
				} while (rs.next());
				valida = true;
			} else {
				System.out.println("N�O H� TURMAS CADASTRADAS PARA ESTE CURSO!!\n");
				valida = false;

			}

		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			// Fecha as conex�es

			try {
				if (pstm != null) {

					pstm.close();
				}

				if (con != null) {
					con.close();
				}

			} catch (Exception e) {

				e.printStackTrace();
			}

		}
		return valida;
	}

	public int listarTurmaPorId(int codCurso,int idTurma) {
		String sql = "SELECT Turma.idTurma FROM Turma "
				+ "WHERE Turma.idTurma = " + idTurma
				+ " AND Turma.idCurso = "+codCurso;
		Connection con = null;
		Statement pstm = null;
		int codTurma = 0;

		try {

			con = Conexao.Conectar();
			pstm = con.prepareStatement(sql);

			ResultSet rs = pstm.executeQuery(sql);
			if (rs.next()) {
				do {
					codTurma = rs.getInt("idTurma");
				} while (rs.next());
			} else {
				codTurma = 0;
			}

		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			// Fecha as conex�es

			try {
				if (pstm != null) {

					pstm.close();
				}

				if (con != null) {
					con.close();
				}

			} catch (Exception e) {

				e.printStackTrace();
			}

		}
		return codTurma;

	}
}
