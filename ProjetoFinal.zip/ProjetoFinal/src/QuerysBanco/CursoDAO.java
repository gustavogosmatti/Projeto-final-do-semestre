package QuerysBanco;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import ProjetoFinal.Curso;

public class CursoDAO {

	public void CadastrarCurso(Curso c) {
		String sql = "INSERT INTO Curso(nomeCurso)" + " VALUES(?)";

		Connection con = null;
		PreparedStatement pstm = null;

		try {

			con = Conexao.Conectar();
			pstm = con.prepareStatement(sql);

			pstm.setString(1, c.getNomeCurso());

			pstm.execute();
		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			// Fecha as conex�es

			try {
				if (pstm != null) {

					pstm.close();
				}

				if (con != null) {
					con.close();
				}

			} catch (Exception e) {

				e.printStackTrace();
			}
		}
	}

	public boolean listarCursos() {
		String sql = "SELECT * FROM Curso";
		Connection con = null;
		Statement pstm = null;
		boolean valida = false;
		try {

			con = Conexao.Conectar();
			pstm = con.prepareStatement(sql);

			ResultSet rs = pstm.executeQuery(sql);
			if(rs.next()) {
				do {
					int codCurso = rs.getInt("idCurso");
					String nomeCurso = rs.getString("nomeCurso");

					System.out.println(codCurso + " - " + nomeCurso);
				}while(rs.next());
				valida = true;
			}
			else {
				System.out.println("N�O H� CURSOS CADASTRADOS!!\n");
				valida = false;
			}
			
				

			

		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			// Fecha as conex�es

			try {
				if (pstm != null) {

					pstm.close();
				}

				if (con != null) {
					con.close();
				}

			} catch (Exception e) {

				e.printStackTrace();
			}

		}
		return valida;
	}

	public int ListarCursoPorId(int idCurso) {

		String sql = "SELECT idCurso FROM Curso WHERE idCurso = " + idCurso;
		Connection con = null;
		Statement pstm = null;
		int codCurso = 0;

		try {

			con = Conexao.Conectar();
			pstm = con.prepareStatement(sql);

			ResultSet rs = pstm.executeQuery(sql);
			while (rs.next()) {
				codCurso = rs.getInt("idCurso");
			}
		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			// Fecha as conex�es

			try {
				if (pstm != null) {

					pstm.close();
				}

				if (con != null) {
					con.close();
				}

			} catch (Exception e) {

				e.printStackTrace();
			}

		}

		return codCurso;
	}
}
