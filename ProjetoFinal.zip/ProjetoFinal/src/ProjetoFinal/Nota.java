package ProjetoFinal;

public class Nota {
	private double nota;
	private int codAluno;
	private int codDisciplina;

	public Nota(double nota, int codAluno, int codDisciplina) {

		this.nota = nota;
		this.codAluno = codAluno;
		this.codDisciplina = codDisciplina;
	}

	public double getNota() {
		return nota;
	}

	public void setNota(double nota) {
		this.nota = nota;
	}

	public int getCodAluno() {
		return codAluno;
	}

	public void setCodAluno(int codAluno) {
		this.codAluno = codAluno;
	}

	public int getCodDisciplina() {
		return codDisciplina;
	}

	public void setCodDisciplina(int codDisciplina) {
		this.codDisciplina = codDisciplina;
	}

}
