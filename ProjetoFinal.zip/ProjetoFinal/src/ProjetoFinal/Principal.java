package ProjetoFinal;

import MenuCadastros.Cadastrar;
import QuerysBanco.AlunoDAO;
import QuerysBanco.CursoDAO;
import QuerysBanco.DisciplinaDAO;
import QuerysBanco.NotaDAO;
import QuerysBanco.ProfessorDAO;
import QuerysBanco.TurmaDAO;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeParseException;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Principal {

	public static void main(String[] args) throws Exception {

		Scanner s = new Scanner(System.in);
		AlunoDAO alunoDao = new AlunoDAO();
		CursoDAO cursoDao = new CursoDAO();
		TurmaDAO turmaDao = new TurmaDAO();
		NotaDAO notaDao = new NotaDAO();

		DisciplinaDAO disciplinaDao = new DisciplinaDAO();
		ProfessorDAO professorDao = new ProfessorDAO();
		Cadastrar cadastrar = new Cadastrar();

		int opcCurso;
		int codCurso = 0;
		int opcTurma;
		int codTurma = 0;
		int opcDisciplina;
		int codDisciplina = 0;
		int opcAluno;
		int codAluno = 0;

		boolean valida = false;

		int opcMenu = 0;
		do {
			do {
				try {
					System.out.println("---------------ESCOLHA UMA DAS OP��ES----------------");
					System.out.println("1 - Cadastrar Alunos");
					System.out.println("2 - Cadastrar Professores");
					System.out.println("3 - Cadastrar Turmas");
					System.out.println("4 - Cadastrar Cursos");
					System.out.println("5 - Cadastrar Disciplina");
					System.out.println("6 - Relat�rio de alunos por curso");
					System.out.println("7 - Relat�rio de disciplinas por curso");
					System.out.println("8 - Avaliar aluno por disciplina");
					System.out.println("9 - Relat�rio acad�mico por aluno");
					System.out.println("10 - Relat�rio de turmas");
					System.out.println("0 - Sair");
					opcMenu = s.nextInt();
					valida = true;
				} catch (InputMismatchException e) {
					System.out.println("DIGITE SOMENTE N�MEROS");
					valida = false;
					s.nextLine();
				}
			} while (valida == false);

			switch (opcMenu) {
			case 1:

				alunoDao.CadastrarAluno(cadastrar.CadastrarAluno());

				break;
			case 2:
				professorDao.cadastrarProfessor(cadastrar.cadastrarProfessor());
				break;
			case 3:
				turmaDao.cadastrarTurma(cadastrar.cadastrarTurma());
				break;

			case 4:
				cursoDao.CadastrarCurso(cadastrar.cadastrarCurso());
				break;

			case 5:
				disciplinaDao.cadastrarDisciplina(cadastrar.cadastrarDisciplina());

				break;

			case 6:

				do {
					do {
						try {
							System.out.println("SELECIONE UM CURSO: \n");
							cursoDao.listarCursos();
							opcCurso = s.nextInt();
							codCurso = cursoDao.ListarCursoPorId(opcCurso);
							valida = true;
						} catch (InputMismatchException e) {
							System.out.println("DIGITE UMA OP��O V�LIDA!!\n");
							valida = false;
							s.nextLine();
						}
					} while (valida == false);
				} while (codCurso == 0);

				s.nextLine();
				codTurma = 0;
				do {
					do {
						try {
							System.out.println("SELECIONE UMA TURMA:\n");
							if (turmaDao.listarTurmaPorCurso(codCurso) == false) {

								codTurma = -1;

							} else {
								int opc = s.nextInt();
								codTurma = turmaDao.listarTurmaPorId(codCurso, opc);

							}
							valida = true;
						} catch (InputMismatchException e) {
							System.out.println("DIGITE UMA OP��O V�LIDA!!\n");
							valida = false;
							s.nextLine();
						}
					} while (valida == false);
				} while (codTurma == 0);

				alunoDao.listarAlunosPorCurso(codTurma, codCurso);

				break;

			case 7:
				do {
					try {
						disciplinaDao.listarDisciplinasPorCurso();
						valida = true;
					} catch (InputMismatchException e) {

						System.out.println("DIGITE UMA OP��O V�LIDA!!\n");
						valida = false;
					}
				} while (valida == false);
				break;

			case 8:

				do {
					do {
						try {
							System.out.println("SELECIONE UM CURSO: \n");
							if (cursoDao.listarCursos() == false) {
								break;

							} else {
								opcCurso = s.nextInt();
								codCurso = cursoDao.ListarCursoPorId(opcCurso);
							}
							valida = true;
						} catch (InputMismatchException e) {
							System.out.println("DIGITE UMA OP��O V�LIDA!!\n");
							valida = false;
							s.nextLine();
						}
					} while (valida == false);

				} while (codCurso == 0);

				do {
					do {
						try {
							System.out.println("\nSELECIONE UMA TURMA:");
							if (turmaDao.listarTurmaPorCurso(codCurso) == false) {
								codTurma = -1;

							} else {
								opcTurma = s.nextInt();
								codTurma = turmaDao.listarTurmaPorId(codCurso, opcTurma);

							}
							valida = true;
						} catch (InputMismatchException e) {
							System.out.println("DIGITE UMA OP��O V�LIDA!!\n");
							valida = false;
							s.nextLine();
						}
					} while (valida == false);

				} while (codTurma == 0);
				if (codTurma != -1) {
					do {
						do {
							try {
								System.out.println("\nSELECIONE UM ALUNO:");
								if (alunoDao.listarAlunos(codTurma, codCurso) == false) {
									codAluno = -1;
								} else {
									opcAluno = s.nextInt();
									codAluno = alunoDao.listarAlunosPorId(codTurma, codCurso, opcAluno);
								}
								valida = true;
							} catch (InputMismatchException e) {
								System.out.println("DIGITE UMA OP��O V�LIDA!!\n");
								valida = false;
								s.nextLine();
							}
						} while (valida == false);

					} while (codAluno == 0);
				}
				if (codAluno != -1 && codTurma != -1) {
					do {
						do {
							try {
								System.out.println("\nSELECIONE UMA DISCIPLINA: ");
								if (disciplinaDao.listarDisciplinasDoCurso(codCurso) == false) {
									codDisciplina = -1;
								} else {
									opcDisciplina = s.nextInt();
									codDisciplina = disciplinaDao.listarDisciplinaPorId(opcDisciplina);
								}
								valida = true;
							} catch (InputMismatchException e) {
								System.out.println("DIGITE UMA OP��O V�LIDA!!\n");
								valida = false;
								s.nextLine();
							}
						} while (valida == false);

					} while (codDisciplina == 0);

					do {
						try {
							if (codDisciplina != -1) {
								System.out.println("Digite a nota dessa disciplina: ");
								double notaDisciplina = s.nextDouble();
								Nota nota = new Nota(notaDisciplina, codAluno, codDisciplina);
								if (notaDao.verificarSeNotaExiste(codAluno, codDisciplina) == -1) {
									notaDao.CadastrarNotaDisciplina(nota);
								} else {
									notaDao.alterarNota(notaDao.verificarSeNotaExiste(codAluno, codDisciplina),
											notaDisciplina);
								}
							} else {

							}

							valida = true;
						} catch (InputMismatchException e) {
							System.out.println("DIGITE UM VALOR V�LIDO!!\n");
							valida = false;
							s.nextLine();
						}
					} while (valida == false);
				}
				if (codAluno == -1) {
					System.out.println("\nA OPERA��O FOI ENCERRADA POIS:\n- N�O TEM ALUNOS NESTA TURMA PARA AVALIAR");
				} else if (codDisciplina == -1) {
					System.out
							.println("\nA OPERA��O FOI ENCERRADA POIS:\n- N�O TEM DISCIPLINAS CADASTRADAS NESTE CURSO");
				} else if (codTurma == -1) {
					System.out
							.println("\nA OPERA��O FOI ENCERRADA POIS:\n- N�O TEM TURMAS CADASTRADAS COM ESTE CURSO\n");
				}
				if (codAluno == -1 && codDisciplina == -1) {

					System.out.println("- N�O TEM DISCIPLINAS CADASTRADAS NESTE CURSO");
				}
				if (codAluno == -1 && codDisciplina == -1 && codTurma == -1) {
					System.out.println("- N�O TEM TURMAS CADASTRADAS COM ESTE CURSO\n");
				}

				break;

			case 9:
				do {
					do {
						try {
							System.out.println("SELECIONE UM CURSO: \n");
							cursoDao.listarCursos();
							opcCurso = s.nextInt();
							codCurso = cursoDao.ListarCursoPorId(opcCurso);
							valida = true;
						} catch (InputMismatchException e) {
							System.out.println("DIGITE UMA OP��O V�LIDA!!\n");
							valida = false;
							s.nextLine();
						}
					} while (valida == false);

				} while (codCurso == 0);

				do {
					do {
						try {
							System.out.println("\nSELECIONE UMA TURMA:");
							if (turmaDao.listarTurmaPorCurso(codCurso) == false) {
								codTurma = -1;

							} else {
								opcTurma = s.nextInt();
								codTurma = turmaDao.listarTurmaPorId(codCurso, opcTurma);

							}
							valida = true;
						} catch (InputMismatchException e) {
							System.out.println("DIGITE UMA OP��O V�LIDA!!\n");
							valida = false;
							s.nextLine();
						}

					} while (valida == false);

				} while (codTurma == 0);

				do {
					do {
						try {
							System.out.println("\nSELECIONE UM ALUNO:");
							if (alunoDao.listarAlunos(codTurma, codCurso) == false) {
								codAluno = -1;
							} else {
								opcAluno = s.nextInt();
								codAluno = alunoDao.listarAlunosPorId(codTurma, codCurso, opcAluno);
							}
							valida = true;
						} catch (InputMismatchException e) {
							System.out.println("DIGITE UMA OP��O V�LIDA!!\n");
							valida = false;
							s.nextLine();
						}
					} while (valida == false);

				} while (codAluno == 0);

				notaDao.listarRelatorioAcademicoAluno(codCurso, codAluno);
				break;
			case 10:
				turmaDao.listarTurmas();
				break;
				
			case 0:
				System.out.println("VOC� SAIU!!");
				break;
			default:
				System.out.println("DIGITE UMA OP��O V�LIDA!!\n");
				break;
			}

		} while (opcMenu != 0);

	}

}
